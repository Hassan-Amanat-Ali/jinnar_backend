// controllers/jobRequestController.js
import JobRequest from '../models/JobRequest.js';
import User from '../models/User.js';
import flw from '../config/flutterwave.js';

// ───────────────────────────────────────
// 1. CREATE JOB REQUEST (Buyer)
// ───────────────────────────────────────
export const createJobRequest = async (req, res) => {
  try {
    const { id: buyerId } = req.user;
    const {
      title, description, category, images,
      lat, lng, address, budget, preferredDate, timeSlot
    } = req.body;

    const buyer = await User.findById(buyerId);
    if (!buyer || !buyer.isVerified) return res.status(403).json({ error: 'Not verified' });

    const job = new JobRequest({
      buyerId,
      title, description, category, images,
      location: { lat, lng, address },
      budget, preferredDate, timeSlot
    });

    await job.save();

    res.status(201).json({
      message: 'Job posted!',
      jobRequest: {
        _id: job._id,
        title: job.title,
        budget: job.budget,
        status: job.status
      }
    });

  } catch (error) {
    res.status(500).json({ error: 'Failed to post job' + error });
  }
};

// ───────────────────────────────────────
// 2. GET MY JOB REQUESTS (Buyer)
// ───────────────────────────────────────
export const getMyJobRequests = async (req, res) => {
  try {
    const { id } = req.user;
    const jobs = await JobRequest.find({ buyerId: id })
      .populate('acceptedBy', 'name profileImage')
      .sort({ createdAt: -1 });
    res.json({ jobs });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch' + error});
  }
};

// ───────────────────────────────────────
// 3. GET AVAILABLE JOBS (Seller)
// ───────────────────────────────────────
export const getAvailableJobs = async (req, res) => {
  try {
    const { id } = req.user;
    const jobs = await JobRequest.find({
      status: 'open',
      buyerId: { $ne: id },
      declinedBy: { $ne: id }
    })
      .populate('buyerId', 'name profileImage')
      .sort({ createdAt: -1 })
      .limit(20);
    res.json({ jobs });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch jobs' + error});
  }
};

// ───────────────────────────────────────
// 4. ACCEPT JOB (Seller)
// ───────────────────────────────────────
export const acceptJob = async (req, res) => {
  try {
    const { id } = req.params;
    const { id: sellerId } = req.user;

    const job = await JobRequest.findById(id);
    if (!job || job.status !== 'open') return res.status(400).json({ error: 'Job not available' });

    job.status = 'accepted';
    job.acceptedBy = sellerId;
    job.acceptedAt = new Date();
    await job.save();

    // Notify buyer
    const buyer = await User.findById(job.buyerId);
    buyer.notifications.push({
      type: 'job_accepted',
      content: `${req.user.name} accepted your job: ${job.title}`,
      relatedId: job._id
    });
    await buyer.save();

    res.json({ message: 'Job accepted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to accept' + error});
  }
};

// ───────────────────────────────────────
// 5. DECLINE JOB (Seller)
// ───────────────────────────────────────
export const declineJob = async (req, res) => {
  try {
    const { id } = req.params;
    const { id: sellerId } = req.user;

    const job = await JobRequest.findById(id);
    if (!job || job.status !== 'open') return res.status(400).json({ error: 'Job not available' });

    job.declinedBy.push(sellerId);
    await job.save();

    res.json({ message: 'Job declined' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to decline'+ error });
  }
};

// ───────────────────────────────────────
// 6. SEND MESSAGE (Buyer/Seller)
// ───────────────────────────────────────
export const sendMessage = async (req, res) => {
  try {
    const { id } = req.params;
    const { content, attachments } = req.body;
    const { id: senderId } = req.user;

    const job = await JobRequest.findById(id);
    if (!job) return res.status(404).json({ error: 'Job not found' });

    const isParticipant = job.buyerId.toString() === senderId || 
                         (job.acceptedBy && job.acceptedBy.toString() === senderId);
    if (!isParticipant) return res.status(403).json({ error: 'Not authorized' });

    job.messages.push({
      senderId,
      content,
      attachments
    });
    await job.save();

    res.json({ message: 'Message sent' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send' + error});
  }
};

// ───────────────────────────────────────
// 7. MARK MESSAGES READ
// ───────────────────────────────────────
export const markMessagesRead = async (req, res) => {
  try {
    const { id } = req.params;
    const { id: userId } = req.user;

    const job = await JobRequest.findById(id);
    if (!job) return res.status(404).json({ error: 'Not found' });

    job.messages.forEach(msg => {
      if (msg.senderId.toString() !== userId && !msg.read) {
        msg.read = true;
      }
    });
    await job.save();

    res.json({ message: 'Messages marked read' });
  } catch (error) {
    res.status(500).json({ error: 'Failed' + error});
  }
};

// ───────────────────────────────────────
// 8. UPLOAD DELIVERABLE (Seller)
// ───────────────────────────────────────
export const uploadDeliverable = async (req, res) => {
  try {
    const { id } = req.params;
    const { url, publicId, description } = req.body;
    const { id: sellerId } = req.user;

    const job = await JobRequest.findById(id);
    if (!job || job.acceptedBy.toString() !== sellerId) {
      return res.status(403).json({ error: 'Not your job' });
    }
    if (job.status !== 'accepted') {
      return res.status(400).json({ error: 'Job not accepted' });
    }

    job.deliverables.push({
      url,
      publicId,
      description,
      uploadedBy: sellerId
    });
    job.status = 'completed'; // Ready for payment
    await job.save();

    res.json({ message: 'Work delivered. Awaiting payment.' });

  } catch (error) {
    res.status(500).json({ error: 'Failed to deliver' });
  }
};

// ───────────────────────────────────────
// 9. PAY & REVIEW (Buyer)
// ───────────────────────────────────────
// controllers/jobRequestController.js
export const payAndReview = async (req, res) => {
  try {
    const { id } = req.params;
    const { rating, comment } = req.body;
    const { id: buyerId } = req.user;

    const job = await JobRequest.findById(id)
      .populate('acceptedBy', 'name')
      .populate('buyerId');

    if (!job || job.buyerId.toString() !== buyerId) {
      return res.status(403).json({ error: 'Not your job' });
    }
    if (job.status !== 'completed') {
      return res.status(400).json({ error: 'Work not delivered yet' });
    }
    if (job.paymentStatus !== 'pending') {
      return res.status(400).json({ error: 'Already paid' });
    }

    const amount = job.budget;
    const tx_ref = `JOB-${job._id}-${Date.now()}`;

    const paymentData = {
      tx_ref,
      amount,
      currency: 'KES',
      redirect_url: `${process.env.FRONTEND_URL}/job/${id}/payment-success`,
      customer: {
        email: req.user.email || 'buyer@jinnar.com',
        phone_number: req.user.mobileNumber,
        name: req.user.name
      },
      customizations: {
        title: `Pay for "${job.title}"`,
        description: `Service by ${job.acceptedBy.name}`
      }
    };

    const response = await flw.Transaction.initiate(paymentData);
    if (response.status !== 'success') {
      return res.status(400).json({ error: 'Payment initiation failed' });
    }

    // Save payment refs
    job.flutterwaveTxRef = tx_ref;
    job.flutterwaveFlwRef = response.data.flw_ref;
    job.paymentStatus = 'pending';
    await job.save();

    res.json({
      message: 'Payment link generated',
      paymentLink: response.data.link,
      tx_ref,
      jobId: job._id
    });

  } catch (error) {
    console.error('Pay & Review Error:', error);
    res.status(500).json({ error: 'Payment failed', details: error.message });
  }
};