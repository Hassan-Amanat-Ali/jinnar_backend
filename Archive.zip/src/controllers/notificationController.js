import Notification from '../models/Notification.js';

export const getNotifications = async (req, res, next) => {
  try {
    const { id } = req.user;
    const { unread } = req.query;

    console.log('Get notifications request:', { userId: id, unread });

    const query = { recipientId: id };
    if (unread === 'true') query.isRead = false;

    const notifications = await Notification.find(query)
      .populate('relatedId')
      .sort({ createdAt: -1 });

    console.log('Notifications retrieved:', notifications.length);
    return res.status(200).json({ notifications });
  } catch (error) {
    console.error('Get Notifications Error:', error.message);
    return res.status(500).json({ error: 'Internal Server Error', details: error.message });
  }
};