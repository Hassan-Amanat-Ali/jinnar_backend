import express from 'express';
import {
  createJobRequest, getMyJobRequests, getAvailableJobs,
  acceptJob, declineJob, sendMessage, markMessagesRead,
  uploadDeliverable, payAndReview
} from '../controllers/jobRequestController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

// Buyer
router.post('/', protect, createJobRequest);
router.get('/my-requests', protect, getMyJobRequests);

// Seller
router.get('/available', protect, getAvailableJobs);
router.post('/:id/accept', protect, acceptJob);
router.post('/:id/decline', protect, declineJob);

// Chat
router.post('/:id/message', protect, sendMessage);
router.post('/:id/read', protect, markMessagesRead);

// Delivery & Payment
router.post('/:id/deliver', protect, uploadDeliverable);
router.post('/:id/pay-review', protect, payAndReview);

export default router;