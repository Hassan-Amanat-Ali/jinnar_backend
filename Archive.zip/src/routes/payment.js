import express from 'express';
import { topUpWallet, payForOrder, withdrawFunds, getWallet } from '../controllers/paymentController.js';
import { protect } from '../middleware/auth.js';
import webhookRouter from './webhook.js';

const router = express.Router();

router.post('/topup', protect, topUpWallet);
router.post('/pay-order', protect, payForOrder);
router.post('/withdraw', protect, withdrawFunds);
router.get('/wallet', protect, getWallet);

// Webhook
router.use('/webhook', webhookRouter);

export default router;