// routes/webhook.js
import express from 'express';
import User from '../models/User.js';
import JobRequest from '../models/JobRequest.js';

const router = express.Router();

router.post('/flutterwave', express.raw({ type: 'application/json' }), async (req, res) => {
  const secret_hash = process.env.FLW_WEBHOOK_SECRET;
  const signature = req.headers['verif-hash'];

  if (!signature || signature !== secret_hash) {
    return res.status(401).send('Unauthorized');
  }

  const payload = req.body;

  // Only handle successful charges
  if (payload.event !== 'charge.completed' || payload.data.status !== 'successful') {
    return res.sendStatus(200);
  }

  const tx_ref = payload.data.tx_ref;
  const amount = payload.data.amount;

  // ───────────────────────────────────────
  // 1. WALLET TOP-UP
  // ───────────────────────────────────────
  const user = await User.findOne({ 'wallet.transactions.flutterwaveTxRef': tx_ref });
  if (user) {
    const tx = user.wallet.transactions.find(t => t.flutterwaveTxRef === tx_ref);
    if (tx && tx.status === 'pending') {
      tx.status = 'completed';
      user.wallet.balance += amount;
      await user.save();
      console.log(`Wallet topped up: +${amount} for user ${user._id}`);
    }
  }

  // ───────────────────────────────────────
  // 2. JOB REQUEST PAYMENT
  // ───────────────────────────────────────
  const job = await JobRequest.findOne({ flutterwaveTxRef: tx_ref });
  if (job && job.paymentStatus === 'pending') {
    job.paymentStatus = 'paid';
    job.status = 'completed'; // Final status
    await job.save();

    // Credit seller
    const seller = await User.findById(job.acceptedBy);
    if (seller) {
      seller.wallet.balance += amount;
      seller.wallet.transactions.push({
        type: 'order_earned',
        amount,
        paymentMethod: 'flutterwave',
        orderId: job._id,
        status: 'completed',
        flutterwaveTxRef: tx_ref
      });
      await seller.save();

      // Notify seller
      seller.notifications.push({
        type: 'payment_received',
        content: `You earned KES ${amount} for "${job.title}"`,
        relatedId: job._id
      });
      await seller.save();
    }

    // Notify buyer
    const buyer = await User.findById(job.buyerId);
    if (buyer) {
      buyer.notifications.push({
        type: 'payment_success',
        content: `Payment sent for "${job.title}"`,
        relatedId: job._id
      });
      await buyer.save();
    }

    console.log(`Job paid: ${job._id}, amount: ${amount}`);
  }

  res.sendStatus(200);
});

export default router;