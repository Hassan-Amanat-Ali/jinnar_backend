// models/JobRequest.js
import mongoose from 'mongoose';

const jobRequestSchema = new mongoose.Schema({
  buyerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  title: { type: String, required: true, maxlength: 100 },
  description: { type: String, required: true, maxlength: 2000 },
  category: { type: String, required: true },
  images: [{ url: String, publicId: String }],

  // Location
  location: {
  type: {
    lat: { type: Number, required: true },
    lng: { type: Number, required: true },
    address: { type: String, required: true }
  },
  required: true
},


  // Budget & Time
  budget: { type: Number, required: true },
  preferredDate: { type: Date },
  timeSlot: { type: String, enum: ['morning', 'afternoon', 'evening'] },

  // Status
  status: {
    type: String,
    enum: ['open', 'accepted', 'in-progress', 'completed', 'cancelled', 'disputed'],
    default: 'open'
  },

  // Seller Assignment
  acceptedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  acceptedAt: Date,
  declinedBy: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  // Payment
  paymentStatus: {
    type: String,
    enum: ['pending', 'paid', 'refunded'],
    default: 'pending'
  },
  flutterwaveTxRef: String,
  flutterwaveFlwRef: String,

  // Chat
  messages: [{
    senderId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    content: String,
    attachments: [{ url: String, publicId: String }],
    read: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
  }],

  // Delivery
  deliverables: [{
    url: String,
    publicId: String,
    description: String,
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  }],

  // Review
  review: {
    rating: { type: Number, min: 1, max: 5 },
    comment: String,
    createdAt: Date
  },

  // Cancellation
  cancelledBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  cancellationReason: String

}, { timestamps: true });

// Indexes
jobRequestSchema.index({ buyerId: 1, createdAt: -1 });
jobRequestSchema.index({ status: 1 });
jobRequestSchema.index({ category: 1 });
jobRequestSchema.index({ 'location.lat': 1, 'location.lng': 1 });

export default mongoose.model('JobRequest', jobRequestSchema);