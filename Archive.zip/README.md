===Account Details Needed For Payment Gateway.
M-Pesa
Airtel Money
Tigo Pesa
Debit/Credit Card 
Bank Transfer.