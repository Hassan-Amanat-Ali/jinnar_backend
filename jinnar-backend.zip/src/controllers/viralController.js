import Draw from "../models/Draw.js";
import Submission from "../models/Submission.js";
import Post from "../models/Post.js";
import Reward from "../models/Reward.js";
import User from "../models/User.js";
import mongoose from "mongoose";

// ==================== DRAWS (Public) ====================

export const listDraws = async (req, res, next) => {
  try {
    const status = req.query.status; // active | upcoming | closed
    const filter = {};
    if (status) {
      filter.status = status;
    } else {
      filter.status = { $in: ["active", "upcoming"] };
    }
    const draws = await Draw.find(filter)
      .sort({ startDate: 1 })
      .select("title theme hashtags startDate endDate prizePool status")
      .lean();
    res.json({ success: true, data: draws });
  } catch (err) {
    next(err);
  }
};

export const getDraw = async (req, res, next) => {
  try {
    const draw = await Draw.findById(req.params.id).lean();
    if (!draw) {
      return res.status(404).json({ success: false, error: "Draw not found" });
    }
    res.json({ success: true, data: draw });
  } catch (err) {
    next(err);
  }
};

// ==================== DRAWS (Admin) ====================

export const listAdminDraws = async (req, res, next) => {
  try {
    const draws = await Draw.find({}).sort({ startDate: -1 }).lean();
    res.json({ success: true, data: draws });
  } catch (err) {
    next(err);
  }
};

export const createDraw = async (req, res, next) => {
  try {
    const { title, theme, hashtags, startDate, endDate, prizePool, status } = req.body;
    const draw = await Draw.create({
      title,
      theme,
      hashtags: hashtags || [],
      startDate,
      endDate,
      prizePool: prizePool ?? 0,
      status: status || "upcoming",
    });
    res.status(201).json({ success: true, data: draw });
  } catch (err) {
    next(err);
  }
};

export const updateDraw = async (req, res, next) => {
  try {
    const draw = await Draw.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true, runValidators: true }
    );
    if (!draw) {
      return res.status(404).json({ success: false, error: "Draw not found" });
    }
    res.json({ success: true, data: draw });
  } catch (err) {
    next(err);
  }
};

// ==================== SUBMISSIONS (Participant) ====================

export const createSubmission = async (req, res, next) => {
  try {
    const userId = req.user._id;
    const { drawId, title } = req.body;
    if (!drawId) {
      return res.status(400).json({ success: false, error: "drawId is required" });
    }
    const videoUrl = req.file ? `/${req.file.path.replace(/\\/g, "/")}` : null;
    if (!videoUrl) {
      return res.status(400).json({ success: false, error: "Video file is required" });
    }

    const draw = await Draw.findById(drawId);
    if (!draw) {
      return res.status(404).json({ success: false, error: "Draw not found" });
    }
    if (draw.status !== "active") {
      return res.status(400).json({ success: false, error: "Draw is not active" });
    }

    const existing = await Submission.findOne({ userId, drawId });
    if (existing) {
      return res.status(409).json({ success: false, error: "One submission per user per draw" });
    }

    const submission = await Submission.create({
      userId,
      drawId,
      videoUrl,
      title: title || null,
      status: "pending",
    });
    await submission.populate("drawId", "title theme status");
    res.status(201).json({ success: true, data: submission });
  } catch (err) {
    next(err);
  }
};

export const listMySubmissions = async (req, res, next) => {
  try {
    const submissions = await Submission.find({ userId: req.user._id })
      .populate("drawId", "title theme startDate endDate status")
      .sort({ createdAt: -1 })
      .lean();
    res.json({ success: true, data: submissions });
  } catch (err) {
    next(err);
  }
};

export const getMySubmission = async (req, res, next) => {
  try {
    const submission = await Submission.findOne({
      _id: req.params.id,
      userId: req.user._id,
    })
      .populate("drawId", "title theme startDate endDate status hashtags")
      .lean();
    if (!submission) {
      return res.status(404).json({ success: false, error: "Submission not found" });
    }
    res.json({ success: true, data: submission });
  } catch (err) {
    next(err);
  }
};

// ==================== POST PROOF ====================

export const createPost = async (req, res, next) => {
  try {
    const userId = req.user._id;
    const { submissionId, drawId, platform, postUrl } = req.body;
    const screenshotUrl = req.file ? `/${req.file.path.replace(/\\/g, "/")}` : null;

    if (!submissionId || !drawId || !platform || !postUrl) {
      return res.status(400).json({
        success: false,
        error: "submissionId, drawId, platform, and postUrl are required",
      });
    }

    const submission = await Submission.findOne({
      _id: submissionId,
      userId,
      drawId,
      status: "approved",
    });
    if (!submission) {
      return res.status(404).json({
        success: false,
        error: "Approved submission not found for this user and draw",
      });
    }

    const platformLower = platform.toLowerCase();
    if (!["tiktok", "facebook", "instagram", "youtube"].includes(platformLower)) {
      return res.status(400).json({ success: false, error: "Invalid platform" });
    }

    const { getPostIdFromUrl, getEngagement } = await import("../services/facebookEngagementService.js");
    const postId = getPostIdFromUrl(platformLower, postUrl);
    if (!postId) {
      return res.status(400).json({ success: false, error: "Could not parse post ID from URL" });
    }

    const existingPost = await Post.findOne({ platform: platformLower, postId });
    if (existingPost) {
      return res.status(409).json({ success: false, error: "This post has already been submitted" });
    }

    let engagement = { likes: 0, comments: 0, shares: 0, saves: 0, views: 0 };
    let verified = false;

    if (platformLower === "facebook") {
      const userWithToken = await User.findById(userId).select("+socialAccounts.facebook.accessToken").lean();
      const token = userWithToken?.socialAccounts?.facebook?.accessToken;
      if (token) {
        try {
          const apiEngagement = await getEngagement(postId, token);
          if (apiEngagement) {
            engagement = apiEngagement;
            verified = true;
          }
        } catch (e) {
          console.warn("Facebook API engagement fetch failed:", e.message);
        }
      }
    }

    const post = new Post({
      userId,
      drawId,
      submissionId,
      platform: platformLower,
      postUrl,
      postId,
      engagement,
      screenshotUrl: screenshotUrl || undefined,
      verified,
    });
    post.calculatePoints();
    await post.save();

    if (verified) {
      await updateUserTotalPoints(userId);
    }

    const populated = await Post.findById(post._id)
      .populate("drawId", "title")
      .populate("submissionId", "title")
      .lean();
    res.status(201).json({ success: true, data: populated });
  } catch (err) {
    next(err);
  }
};

async function updateUserTotalPoints(userId) {
  const sum = await Post.aggregate([
    { $match: { userId: new mongoose.Types.ObjectId(userId), verified: true } },
    { $group: { _id: null, total: { $sum: "$points" } } },
  ]);
  const totalPoints = sum[0]?.total ?? 0;
  await User.findByIdAndUpdate(userId, { totalPoints });
}

// ==================== LEADERBOARD ====================

export const getLeaderboard = async (req, res, next) => {
  try {
    const { drawId, scope = "global", country, city, limit = 50, offset = 0 } = req.query;
    if (!drawId) {
      return res.status(400).json({ success: false, error: "drawId is required" });
    }

    const match = { drawId: new mongoose.Types.ObjectId(drawId), verified: true };
    const pipeline = [
      { $match: match },
      { $group: { _id: "$userId", totalPoints: { $sum: "$points" } } },
      {
        $lookup: {
          from: "users",
          localField: "_id",
          foreignField: "_id",
          as: "user",
        },
      },
      { $unwind: "$user" },
    ];

    if (scope === "country" && country) {
      pipeline.push({ $match: { "user.country": country } });
    } else if (scope === "city" && city) {
      pipeline.push({ $match: { "user.city": city } });
    }

    pipeline.push(
      { $sort: { totalPoints: -1 } },
      { $skip: parseInt(offset, 10) || 0 },
      { $limit: Math.min(parseInt(limit, 10) || 50, 100) }
    );

    const results = await Post.aggregate(pipeline);
    const withRank = results.map((r, i) => ({
      rank: (parseInt(offset, 10) || 0) + i + 1,
      userId: r._id,
      name: r.user?.name,
      profilePicture: r.user?.profilePicture,
      country: r.user?.country,
      city: r.user?.city,
      totalPoints: r.totalPoints,
    }));

    res.json({ success: true, data: withRank });
  } catch (err) {
    next(err);
  }
};

export const getMyRank = async (req, res, next) => {
  try {
    const userId = req.user._id;
    const { drawId } = req.query;
    if (!drawId) {
      return res.status(400).json({ success: false, error: "drawId is required" });
    }

    const myPoints = await Post.aggregate([
      { $match: { drawId: new mongoose.Types.ObjectId(drawId), userId: new mongoose.Types.ObjectId(userId), verified: true } },
      { $group: { _id: null, totalPoints: { $sum: "$points" } } },
    ]);
    const totalPoints = myPoints[0]?.totalPoints ?? 0;

    const rankPipeline = [
      { $match: { drawId: new mongoose.Types.ObjectId(drawId), verified: true } },
      { $group: { _id: "$userId", totalPoints: { $sum: "$points" } } },
      { $sort: { totalPoints: -1 } },
      { $group: { _id: null, ids: { $push: "$_id" } } },
    ];
    const [rankResult] = await Post.aggregate(rankPipeline);
    const ids = rankResult?.ids || [];
    const globalRank = ids.findIndex((id) => id.toString() === userId.toString()) + 1 || null;

    const user = await User.findById(userId).select("country city").lean();
    let countryRank = null;
    let cityRank = null;
    if (user?.country) {
      const countryUserIds = await User.find({ country: user.country }).distinct("_id");
      const countryLeaders = await Post.aggregate([
        { $match: { drawId: new mongoose.Types.ObjectId(drawId), verified: true, userId: { $in: countryUserIds } } },
        { $group: { _id: "$userId", totalPoints: { $sum: "$points" } } },
        { $sort: { totalPoints: -1 } },
      ]);
      countryRank = countryLeaders.findIndex((r) => r._id.toString() === userId.toString()) + 1 || null;
    }
    if (user?.city) {
      const cityUserIds = await User.find({ city: user.city }).distinct("_id");
      const cityLeaders = await Post.aggregate([
        { $match: { drawId: new mongoose.Types.ObjectId(drawId), verified: true, userId: { $in: cityUserIds } } },
        { $group: { _id: "$userId", totalPoints: { $sum: "$points" } } },
        { $sort: { totalPoints: -1 } },
      ]);
      cityRank = cityLeaders.findIndex((r) => r._id.toString() === userId.toString()) + 1 || null;
    }

    res.json({
      success: true,
      data: { drawId, totalPoints, globalRank, countryRank, cityRank },
    });
  } catch (err) {
    next(err);
  }
};

// ==================== POINTS ====================

export const getMyPoints = async (req, res, next) => {
  try {
    const userId = req.user._id;
    const { drawId } = req.query;

    const match = { userId: new mongoose.Types.ObjectId(userId), verified: true };
    if (drawId) match.drawId = new mongoose.Types.ObjectId(drawId);

    const [totalResult, posts] = await Promise.all([
      Post.aggregate([{ $match: match }, { $group: { _id: null, totalPoints: { $sum: "$points" } } }]),
      Post.find(match).sort({ createdAt: -1 }).limit(50).populate("drawId", "title").lean(),
    ]);

    const totalPoints = totalResult[0]?.totalPoints ?? 0;
    res.json({ success: true, data: { totalPoints, posts } });
  } catch (err) {
    next(err);
  }
};

// ==================== REWARDS & WINNERS ====================

export const getWinners = async (req, res, next) => {
  try {
    const rewards = await Reward.find({ drawId: req.params.drawId })
      .populate("winnerUserId", "name profilePicture country")
      .sort({ rank: 1 })
      .lean();
    res.json({ success: true, data: rewards });
  } catch (err) {
    next(err);
  }
};

export const getMyRewards = async (req, res, next) => {
  try {
    const rewards = await Reward.find({ winnerUserId: req.user._id })
      .populate("drawId", "title endDate")
      .sort({ createdAt: -1 })
      .lean();
    res.json({ success: true, data: rewards });
  } catch (err) {
    next(err);
  }
};

// ==================== ADMIN: REWARDS & CLOSE DRAW ====================

export const createRewards = async (req, res, next) => {
  try {
    const { drawId } = req.params;
    const rewards = req.body; // array of { rank, rewardType, amount }
    if (!Array.isArray(rewards) || rewards.length === 0) {
      return res.status(400).json({ success: false, error: "Body must be an array of { rank, rewardType, amount }" });
    }
    const created = await Reward.insertMany(
      rewards.map((r) => ({ drawId, rank: r.rank, rewardType: r.rewardType, amount: r.amount }))
    );
    res.status(201).json({ success: true, data: created });
  } catch (err) {
    next(err);
  }
};

export const closeDraw = async (req, res, next) => {
  try {
    const { drawId } = req.params;
    const draw = await Draw.findById(drawId);
    if (!draw) {
      return res.status(404).json({ success: false, error: "Draw not found" });
    }

    const leaderboard = await Post.aggregate([
      { $match: { drawId: new mongoose.Types.ObjectId(drawId), verified: true } },
      { $group: { _id: "$userId", totalPoints: { $sum: "$points" } } },
      { $sort: { totalPoints: -1 } },
    ]);

    const rewards = await Reward.find({ drawId }).sort({ rank: 1 });
    for (const reward of rewards) {
      const winner = leaderboard[reward.rank - 1];
      if (winner) {
        reward.winnerUserId = winner._id;
        reward.status = "pending";
        await reward.save();
      }
    }

    draw.status = "closed";
    await draw.save();

    res.json({ success: true, data: draw, message: "Draw closed and winners assigned" });
  } catch (err) {
    next(err);
  }
};

// ==================== ADMIN: SUBMISSIONS ====================

export const listAdminSubmissions = async (req, res, next) => {
  try {
    const { status = "pending", drawId } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (drawId) filter.drawId = drawId;
    const submissions = await Submission.find(filter)
      .populate("userId", "name profilePicture email")
      .populate("drawId", "title theme status")
      .sort({ createdAt: -1 })
      .lean();
    res.json({ success: true, data: submissions });
  } catch (err) {
    next(err);
  }
};

export const updateSubmission = async (req, res, next) => {
  try {
    const { status, reviewNotes } = req.body;
    if (!status || !["approved", "rejected"].includes(status)) {
      return res.status(400).json({ success: false, error: "status must be approved or rejected" });
    }
    const submission = await Submission.findByIdAndUpdate(
      req.params.id,
      {
        status,
        reviewNotes: reviewNotes || null,
        reviewerId: req.user._id,
      },
      { new: true }
    ).populate("drawId", "title");
    if (!submission) {
      return res.status(404).json({ success: false, error: "Submission not found" });
    }
    res.json({ success: true, data: submission });
  } catch (err) {
    next(err);
  }
};

// ==================== ADMIN: POSTS ====================

export const updatePost = async (req, res, next) => {
  try {
    const updates = {};
    if (req.body.verified !== undefined) updates.verified = req.body.verified;
    if (req.body.fraudFlag !== undefined) updates.fraudFlag = req.body.fraudFlag;
    if (req.body.engagement) updates.engagement = req.body.engagement;

    const post = await Post.findById(req.params.id);
    if (!post) {
      return res.status(404).json({ success: false, error: "Post not found" });
    }
    if (updates.engagement) {
      Object.assign(post.engagement, updates.engagement);
      post.calculatePoints();
    }
    Object.assign(post, updates);
    await post.save();

    res.json({ success: true, data: post });
  } catch (err) {
    next(err);
  }
};
