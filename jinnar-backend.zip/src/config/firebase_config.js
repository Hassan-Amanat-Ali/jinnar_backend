// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyC71hBg73rpkySVVZ86B3B7pPXYiT7O8TE",
//   authDomain: "tanzaniaservices-739c2.firebaseapp.com",
//   projectId: "tanzaniaservices-739c2",
//   storageBucket: "tanzaniaservices-739c2.firebasestorage.app",
//   messagingSenderId: "1007107385150",
//   appId: "1:1007107385150:web:2ead6cd5f212abd105ee6f",
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);
